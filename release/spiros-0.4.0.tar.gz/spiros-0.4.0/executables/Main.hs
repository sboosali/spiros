import qualified Example.Spiros
main = Example.Spiros.main